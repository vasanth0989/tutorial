require.config({
    paths: {
        jquery: 'jquery-2.1.1.min',
        templates: '../templates',
        hbs: '../../node_modules/require-handlebars-plugin/hbs'
    }
});

require(["app"], function (app) {
    app.init();
});