require(["app"], function (app) {
    app.init();
});